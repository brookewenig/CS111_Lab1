exec echo a
